/*Napište program, který od uživatele načte dopředu neznámý počet přirozených čísel (očekávejte, že uživatel bude skutečně zadávat pouze přirozená čísla). Toto načítání bude fungovat tak, že uživatel zadá číslo a stiskne enter, pak může zadat další číslo a zase stiskne enter, atd. Zadávání ukončí tím, že nezadá žádné číslo (nenapíše do konzole nic) a stiskne enter. Poté program na konzoli vypíše na jeden řádek zadaná čísla, přičemž vynechá to, které bylo zadané jako první. Čísla budou vypsána v obráceném pořadí, než jak byla zadána, přičemž budou oddělena podtržítkem.

Omezení: je zakázáno použít metodu reverse.*/

print("Zadejte přirozená čísla (pro ukončení stiskněte enter bez zadání čísla): ");

let vstup = [];
let vystup = [];

while(true) {
    let cislo = prompt();
    if(cislo === ""){
        break;
    }
    vstup.push(Number(cislo));
}

for(let i = vstup.length - 1; i > 0; i--){
    vystup.push(vstup[i]);
}
print(vystup.join("_"));





// V programu si na začátku definujte proměnnou obsahující pole, které bude neprázdné a bude obsahovat pole celých čísel, kde jedno
//  vnořené pole reprezentuje jeden řádek matice.
// Napište program, který vypíše matici na konzoli tak, že v jednotlivých sloupcích budou čísla zarovnána na úrovni jednotek. 
// Jednotlivé sloupce budou od sebe odděleny právě jednou mezerou.



pole = [[5,15,-100,200],
       [2000,5,10,-50],
       [300,-30,400,9]]

let matice = "";

for(let i = 0; i < pole.length; i++){                   //pro každý řádek matice"
    for(let j = 0; j < pole[i].length; j++){         //pro každé číslo v aktuálním řádku
        matice += pole[i][j] + " ";
    }
    matice += "\n";
}
print(matice);



//Napište metodu insertToArray(array, arrayToInsert, idx). Princip této metody bude takový, že do pole array vloží na index idx prvky z pole arrayToInsert tak, že pokud se na daném indexu v poli již nějaký prvek nachází, pak bude tento a případné prvky vpravo od něj posunuty doprava. Metoda vrátí pole arr s vloženými prvky. Princip metody pro jeden i více vkládaných prvků je ilustrován v následujících ukázkách použití této metody.
//Omezení: je zakázáno použít metodu splice či jinou obdobnou metodu, která řeší právě toto vkládání s posunem na daný index.

function insertToArray(array, arrayToInsert, idx){
    let vysledek = [];
    for(let i = 0; i < idx; i++){
        vysledek.push(array[i]);
    }
    for(let i = 0; i < arrayToInsert.length; i++){
        vysledek.push(arrayToInsert[i]);
        }
    for(let i = idx; i < array.length; i++){
        vysledek.push(array[i]);
    }
    return vysledek;
}

//nebo   

function insertToArray(array, arrayToInsert, idx) {
    let left = array.slice(0, idx);
    let right = array.slice(idx);

    return left.concat(arrayToInsert, right);
}

/*V programu si na začátku definujte proměnnou typu pole, které bude neprázdné a může obsahovat libovolné množství celých čísel.
 Napište program, který vypíše prvek pole, pro který platí, že je nejmenším z prvků pole, které jsou větší než prostý aritmetický průměr všech prvků pole.
  Pokud takový prvek neexistuje, pak o tom program srozumitelně uživatele informuje. Analogicky program vypíše prvek, který je největším z prvků pole, které jsou menší než průměr.
  Při výpočtu prostého aritmetického průměru používejte celočíselné dělení.
Omezení.: není povoleno na poli použít vestavěnou třídící metodu či metodu, která přímo spočte průměr prvků z pole.
 Nicméně pokud byste chtěli (což ale neznamená, že to je nutné) provést setřídění pole, pak si jej můžeme sami naimplementovat.*/

 let pole = [5,6,4];
 let prumer = 0;
 let vetsiPole = [];
 let mensiPole = [];


 for(let i = 0; i < pole.length; i++){
    prumer += pole[i];
 }
 prumer = Math.floor(prumer / pole.length);

 for(let i = 0; i < pole.length; i++){
    if(pole[i] > prumer){
        vetsiPole.push(pole[i]);
    }
    else if(pole[i] < prumer){
        mensiPole.push(pole[i]);
    }
}
if(vetsiPole.length > 0){
    let nejmensi = vetsiPole[0];
    for(let i = 1; i < vetsiPole.length; i++){
        if(vetsiPole[i] < nejmensi){
            nejmensi = vetsiPole[i];
        }
    }
    console.log("Nejmenší prvek větší než průměr: " + nejmensi);
}
else {
    console.log("Neexistuje prvek větší než průměr.");
}


 
if(mensiPole.length > 0){
    let nejvetsi = mensiPole[0];
    for(let i = 1; i < mensiPole.length; i++){
        if(mensiPole[i] > nejvetsi){
            nejvetsi = mensiPole[i];
        }
    }
    console.log("Největší prvek menší než průměr: " + nejvetsi);
}
else {
    console.log("Neexistuje prvek menší než průměr.");
}

//Sečtěte čísla v poli.
let pole = [1,2,3,4,5];
let soucet = 0;

for(let i = 0; i < pole.length; i++){
    soucet += pole[i];
}
console.log("Součet čísel v poli: " + soucet);

//Seřaďte čísla v poli podle abecedy.

let pole = [1, 2, 3, 4, 5];
let poleString = pole.map(String);
poleString.sort();
let poleSerazene = poleString.map(Number);
console.log("Čísla seřazená podle abecedy: " + poleSerazene);

//Najděte nejmenší číslo.
let pole = [5, 2, 9, 1, 5]; 
let nejmensi = pole[0];
for(let i = 1; i < pole.length; i++){
   if (pole[i] < nejmensi) {
    nejmensi = pole[i];
   }
}
console.log("Nejmenší číslo: " + nejmensi);

/*Pole objektů/osob, kde je name, surname, pin (rodné číslo):
Vložte na 2. místo novou osobu.
Vyberte jen ženy.
Vyberte nejmladší osobu.
Seřaďte pole podle příjmení a jména.
Vypište příjmení a jména osob oddělené čárkou. Např. "Novák Jan, Bystrá Jana"*/

let osoby = [
    { name: "Jan", surname: "Novák", pin: "9001011234" },
    { name: "Jana", surname: "Bystrá", pin: "0355056789" },
    { name: "Petr", surname: "Svoboda", pin: "8803121111" }
];
let novaOsoba = { name: "Eva", surname: "Novotná", pin: "9505054321" };
osoby.splice(1, 0, novaOsoba);



let zeny = osoby.filter(osoba=> osoba.pin[2] >= 5);



let nejmladsi = osoby[0];
for(let i = 1; i < osoby.length; i++){
    if(osoby.pin[i] < nejmladsi.pin){
        nejmladsi = osoby[i];
    }
}



osoby.sort((a, b)) => {
    if(a.surname === b.surname && a.name === b.name){
        return 0;
    }
    else if(a.surname === b.surname){
        return a.name < b.name ? -1 : 1;
    }
    else{
        return a.surname < b.surname ? -1 : 1;
    }
}

let vystup = osoby.map(osoba => `${osoba.surname} ${osoba.name}`);
console.log(vystup.join(", "));

//Použijte metodu Object.assign, pro spojení dvou objektů.

let source = {
    jmeno: "Anna",
};
let target = {
    prijmeni: "Valova",
    vek: 22

};

Object.assign(target, source); // target - objekt do ktereho se budou kopirovat vlastnosti source 
console.log(target);

//Použijte spread syntax pro vytvoření klonu, a potom ho vypište.

let source = {
    jmeno: "Anna",
    prijmeni: "Valova",
};
let clone = {...source}; 
console.log(clone);

//Spoj dva objekty v třetí pomocí spread operátoru.

let source1 = {
    jmeno: "Anna",
};
let source2 = {
    prijmeni: "Valova",
    vek: 22
};
let target = {...source1,...source2};
console.log(target); 

/*Napište funkci, která vypíše názvy všech klíčů objektu.
Napište funkci, která projde všechny knihy uložené v poli a pro každou napíše, zdali byla přečtena či nebyla. Vstup:*/

const library = [ 
   {
       author: 'Bill Gates',
       title: 'The Road Ahead',
       readingStatus: true
   },
   {
       author: 'Steve Jobs',
       title: 'Walter Isaacson',
       readingStatus: true
   },
   {
       author: 'Suzanne Collins',
       title:  'Mockingjay: The Final Book of The Hunger Games', 
       readingStatus: false
   }];

   funcion prinrKeys(obj){
    for(let key in obj){
        console,log(key);
    }
   }

   function checkReadingStatus(library){
    for(let i = 0; i  < library.length; i++){
        let book = library[i];
        let status = book.readingStatus ? "prectena:" : "neprectena"; //podmínka ? pokud true ....  : pokud false .....
        console.log(`${book.title} by ${book.author} is ${status}`);

    }
   }
/* Napište funkci, která vyhledá všechny podmnožiny vstupního stringu a vrátí je v poli. vstup: dog očekávaný výstup: ["d", "do", "dog", "o", "og", "g"] */

function getSubsets(str){
    let subsets =[];
    for(let i = 0; i < str.length; i++){
        for(let j = i + 1; j <= str.length; j++ ){
            subsets.push(str.slice(i,j));  //=      let substring = str.slice(i, j); result.push(substring); 
        }
    }
    return subsets;
}




/*4. Napište funkci, která seřadí vstupní pole objektů dle atributu age sestupně. Poté vypište seřazená jména studentů. Vstup: */

const students = [ 
   {
       name: 'Bill',
       surname: 'Gates',
       age: 64
   },
   {
       name: 'Brandon',
       surname: 'Sanderson',
       age: 43
   },
   {
       name: 'Keanu',
       surname: 'Reeves',
       age: 55
   },
   {
       name: 'Duck',
       surname: 'Donald',
       age: 85
   },];

   function sortByAge(students){
    students.sort((a,b) => b.age - a.age); // pro vzestupne a - b 
   }
   sortByAge(students);

   students.forEach(student => console.log(student.name)); //students.forEach(function(student) {console.log(student.name);}); - > to stejne akorat starsi zapis , my mame arrw funkci - novejsi 

   //Převeďte vstupní pole na set a vypište. Vstup: ["Adam", "Bára", "Adam", "Karel", "Matěj", "Jakub", "Jakub", "JAKUB"]

   let array = ["Adam", "Bára", "Adam", "Karel", "Matěj", "Jakub", "Jakub", "JAKUB"];
   let set = new Set(array);
   console.log(set);

   //Vyfiltrujte anagramy. Anagram neboli přesmyčka je slovo či více slov, která vzniknou z původního slova či více slov tak, že se použijí všechna písmena v původním výrazu obsažená a změní se jejich pořadí.

   let anagrams = ["nap", "teachers", "cheaters", "PAN", "ear", "era", "hectares"];
   let uniqueAnagrams = new Set();

   anagrams.forEach(word => {                                          // to stejne co for (let i = 0; i < anagrams.length; i++) { let word = anagrams[i];}
    let sortedWord = word.toLowerCase().split('').sort().join('');
    uniqueAnagrams.add(sortedWord);
   })
console.log(uniqueAnagrams);


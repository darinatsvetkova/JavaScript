//Vytvořte funkci, která ze zadaného data v ISO formátu zjistí a vrátí iso formát posledního dne v zadaném měsíci.

function posledniDenVmesici(isoDatum){
    let datum = new Date(isoDatum);
    let rok = datum.getFullYear();
    let mesic = datum.getMonth() + 1; 
    let posledniDen = new Date(rok, mesic, 0);
    let posledniDenIso = posledniDen.toISOString().split("T")[0];
    return posledniDenIso;
}

//Vytvořte funkci, která ze zadaného data v ISO formátu zjistí a vrátí první den následujícího měsíce.

function prvniDenDalsiMesic(isoDatum){
    let datum = new Date(isoDatum);
    let rok = datum.getFullYear();
    let mesic = datum.getMonth() + 1;
    let prvniDen = new Date(rok, mesic, 1);
    let prvniDenIso = prvniDen.toISOString().split("T")[0];
    return prvniDenIso;
}
//Na začátku si v programu definujte neprázdné pole unikátních řetězců (řetězce budou vždy obsahovat právě jeden znak),
//  které bude obsahovat „povolené znaky“. Napište program, který od uživatele načte řetězec a vypíše „ANO“,
//  pokud obsahuje pouze znaky, které jsou v poli povolených znaků, v opačném případě vypíše „NE“.
//  Pokud uživatel zadá prázdný řetězec, pak program vypíše „NELZE URCIT“.


let povoleneZnaky = ["a", "b", "c", "d", "e"];
let vstup = alert("Zadejte retezec:");
let obsahujePovoleneZnaky = true;

if(vstup === ""){
    console.log("NELZE URCIT");
}
else{
    for(let i = 0; i < vstup.length; i++){
        let char = vstup[i];
       if(!povoleneZnaky.includes(char)){
           obsahujePovoleneZnaky = false;
           console.log("Ne");
           break
       }
    else{
        obsahujePovoleneZnaky = true;
        console.log("Ano");
    }
        
    }
}

//Napište program, který bude mít na začátku definovanou proměnnou obsahující neprázdné pole reprezentující matici.
//  Prvky tohoto pole jsou pole obsahující celá čísla, která reprezentují jednotlivé řádky matice.\
// Program najde řádek, jehož součet prvků je nejvyšší a tento nejvyšší součet vypíše.

let matice = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
];
let nejvyssiSoucet = 0;
for(let i = 0; i < matice.length; i++){
    let radek = matice[i];
    let cisloVRadku = radek[i];
    let soucet = 0;
    for(let j = 0; j < radek.length; j++){
        soucet += radek[j];
    }
    if(soucet > nejvyssiSoucet){
        nejvyssiSoucet = soucet;
    }
}